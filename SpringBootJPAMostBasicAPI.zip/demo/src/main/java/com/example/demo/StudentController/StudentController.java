package com.example.demo.StudentController;



import com.example.demo.Student;
import com.example.demo.StudentService.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/testapi/student")
public class StudentController {

    private StudentService studentService;


    //This Annotatio will Tell Spring boot to use the above variable to instantiate the below method
    @Autowired
    public StudentController(StudentService studentService) {
        this.studentService = studentService;
    }

    @GetMapping("/getStudent")
    public List<Student> getStudent(){
        return  studentService.getStudent();

    }

}
