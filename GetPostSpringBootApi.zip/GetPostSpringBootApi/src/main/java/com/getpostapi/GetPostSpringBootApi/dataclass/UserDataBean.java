package com.getpostapi.GetPostSpringBootApi.dataclass;


import java.util.List;

public class UserDataBean {



    private int code =200;
    private String message =" Success";
    private List<UserData> Data;

    public UserDataBean(int code, String message, List<UserData> data) {
        this.code = code;
        this.message = message;
        Data = data;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public UserDataBean(){

    }

    public UserDataBean(List<UserData> userDataList) {
        this.Data = userDataList;
    }

    public List<UserData> getData() {
        return Data;
    }

    public void setData(List<UserData> data) {
        this.Data = data;
    }
}
