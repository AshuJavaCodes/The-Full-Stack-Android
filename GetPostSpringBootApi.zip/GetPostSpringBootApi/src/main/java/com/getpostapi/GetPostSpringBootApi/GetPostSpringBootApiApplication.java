package com.getpostapi.GetPostSpringBootApi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GetPostSpringBootApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(GetPostSpringBootApiApplication.class, args);
	}

}
